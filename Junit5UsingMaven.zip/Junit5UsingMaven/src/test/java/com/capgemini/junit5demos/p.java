package com.capgemini.junit5demos;

public class p {

	public static Object sq(int i) {
		// TODO Auto-generated method stub
		return i*i;
	}

}
