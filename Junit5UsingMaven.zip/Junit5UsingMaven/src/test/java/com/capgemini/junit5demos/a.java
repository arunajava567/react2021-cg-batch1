package com.capgemini.junit5demos;

public class a {

	public static Object add(int i, int j) {
		// TODO Auto-generated method stub
		return i+j;
	}

}
