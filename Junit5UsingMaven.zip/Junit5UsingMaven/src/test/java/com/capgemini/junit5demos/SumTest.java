package com.capgemini.junit5demos;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SumTest {

	@Test
	void test() {
		assertEquals(9,a.add(4,5));  //TDD
		//fail("Not yet implemented");
	}
	@Test
	void test1() {
		assertEquals(25,p.sq(5));  //TDD
		//fail("Not yet implemented");
	}
}
