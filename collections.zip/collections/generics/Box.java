package com.cg.collections.generics;

import java.util.HashMap;

/*
 * 
 * 	T - Type
	E - Element    ..array element
	K - Key     ..hahsMap key
	N - Number   ..number declaration
	V - Value   ..hahsmap value
 */
//Generic Class


public class Box<T>  //type dec T
{
	///Inetger , double,String ....

	private T a;

	public void add(T a) 
	{
		this.a = a;
	}

	public T get() 
	{
		return a;
	}

	public static void main(String[] args) 
	{
		//HashMap<K,V> m1=new HashMap<K,V>();
		
		Box<Integer> integerBox = new Box<Integer>();

		Box<String> stringBox = new Box<String>();
		
		Box<Double> dBox=new Box<Double>();

		integerBox.add(new Integer(10));
	
		stringBox.add(new String("Hello World"));
		System.out.printf("Integer Value :%d\n\n", integerBox.get());
		System.out.printf("String Value :%s\n", stringBox.get());
		dBox.add(99.99);
		System.out.println(dBox.get());
	}
}