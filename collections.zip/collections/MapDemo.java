package com.cg.collections;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.TreeSet;
public class MapDemo {
	public static void main(String[] args) {
		TreeMap<Integer,Object> hm=new TreeMap<Integer,Object>();
		//LinkedHashMap<Integer,Object> hm=new LinkedHashMap<Integer,Object>();
		//HashMap<Integer,Object> hm=new HashMap<Integer,Object>();
		
		hm.put(1, new String("cg"));
		hm.put(82, new Employee(105,"Ram123"));
		hm.put(79, new Employee(106,"Ram123"));
		
		hm.put(3, new Date());
		hm.put(2, "CG2");
	//	hm.put(null, "Capgemini");
	//	hm.put(null, "Capgemini123");
		hm.put(55, new Employee(102,"Ram"));
		hm.put(46,new Employee(107,"Ram567"));
		hm.put(88, new Employee(108,"Ram567"));
		System.out.println(hm.isEmpty());
		System.out.println(hm.get(3));
		System.out.println(hm.remove(82));
		System.out.println(hm.containsKey(5));
		System.out.println(hm.containsValue("cg"));
		System.out.println(hm);
		Set k=hm.keySet();
		System.out.println(k);//alll keys a set 
		Collection objects=hm.values();
		System.out.println(objects); //values collection 
		
		Set entryset=hm.entrySet();
		Iterator i=entryset.iterator();
		
		while(i.hasNext())
		{			Entry e=(Entry)i.next();
			Integer key=(Integer)e.getKey();
			Object o=e.getValue();
			if( o instanceof Employee)
				System.out.println(key  +"  "+(Employee)o);
			else
				System.out.println(key  +"  "+o);//data. string ,int ....
		}
	/*	HashMap h1=new HashMap();
		h1.put(4, 67);
		h1.put(7, "ty");
		h1.put("a", "b");
		System.out.println(h1);
		int x[]= {3,2,5,6,7,8,1,23};
		Arrays.sort(x);
		for(int xx: x)
			System.out.println(xx);
		System.out.println(Arrays.binarySearch(x, 2));
		List l1=Arrays.asList(34,56,78,89,45,32,12,32);
		Collections.sort(l1);
		System.out.println(l1);
		*/
	}
}
