package com.cg.collections;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

class Employee{
	int id;
	String name;
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + "]";
	}

	public Employee(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	//@Override
	public int hashCode() {
		int hashvalue=(this.name).hashCode();
		return  hashvalue;
	}

	@Override
	public boolean equals(Object obj) {
		Employee e=(Employee)obj;
		boolean result=false;
		if ((this.id==e.id) && this.name.equals(e.name))
			result=true;
		return result;
	}
	
	
	
	
}

public class ListDemo {

	public static void main(String[] args) {
		
		Employee  ee1=new Employee(10,"Ram");
		Employee  ee2=new Employee(10,"Ram");
		System.out.println(ee1.hashCode()+"  "+ee2.hashCode());
		
		HashSet<Employee> empList=new HashSet<Employee>();
		empList.add(new Employee(10,"Ram"));
		empList.add(new Employee(10,"Ram"));
		
		empList.add(new Employee(5,"kiran"));
		empList.add(new Employee(5,"kiran"));
		empList.add(new Employee(8,"Ram123"));
		empList.add(new Employee(50,"RamKymar"));
		empList.add(new Employee(60,"RamReddy"));
		
		System.out.println(empList);
		
		Iterator i=empList.iterator();
		while(i.hasNext() ) {   //to check presence of objects
			  Employee e=(Employee)i.next();
			  
			  System.out.println(e);
			   /* if(e.getId()==8)
			    	e.setName("Ramarav");
			  
			    if(e.getId()==50)
			    	i.remove();*/
				//System.out.println(i.next()); //to display curren tobject
		}
		System.out.println(empList);
		
		Object o[]=empList.toArray();
		
		ArrayList l1=new ArrayList();
		l1.add(10);
		l1.add(20);
		l1.add(30);
		
		Object a[]=l1.toArray();
		for( Object ii:a) {
			
			Integer i1=(Integer)ii;
			System.out.println(i1);
		}
		
	/*	Vector empList=new Vector();  //builtin synchronized*/
		//HashSet empList=new HashSet();//not ordered
		/*
		LinkedHashSet empList=new LinkedHashSet();// ordered
		//empList.add(new Employee(101,"Ram"));
		empList.add(12);
		empList.add(10);
		empList.add(20);
		empList.add(23432.23432);
		empList.add("Capgemini");empList.add("Capgemini");empList.add("Capgemini");
		empList.add(new Date());
		empList.add(12);
		empList.add("Capgemini");
		//empList.add(new Employee(101,"Ram"));
		
		
		//empList.clear();
		System.out.println(empList.contains(12));
		System.out.println(empList.contains("Capgemini"));
	//	System.out.println(empList.indexOf(12));
		System.out.println(empList.remove(3));
		System.out.println(empList.isEmpty());
	//	System.out.println(empList.set(3, "ABC"));
		System.out.println(empList.size());
		System.out.println(empList);
		
		ArrayList l1=new ArrayList();
		l1.add(10);
		l1.add(20);
		l1.add(30);
		System.out.println(empList);                      //bulk operations
		empList.addAll(l1);
		
		System.out.println(empList);
		System.out.println(l1);
		//empList.retainAll(l1);
		empList.removeAll(l1);
		System.out.println(empList);
		//empList.retainAll(l1);
		
		
		System.out.println(empList.containsAll(l1));
		
		
		//List l2=Arrays.asList(30,40,506);
		System.out.println("iterator  loop");
		Iterator i=empList.iterator();
		while(i.hasNext() ) {   //to check presence of objects
				System.out.println(i.next()); //to display curren tobject
		}
		System.out.println("for -each loop");
		for( Object o:empList) {
			System.out.println(o);
		}
		
		TreeSet ts=new TreeSet(); //built in sorting , homogenenous 
		ts.add("Ram");
		ts.add("John");
		ts.add("Abc");
		ts.add("Reddy");
		ts.add("Kumar");
		
		System.out.println(ts);
		
		*/
		
		
	}

	
}
