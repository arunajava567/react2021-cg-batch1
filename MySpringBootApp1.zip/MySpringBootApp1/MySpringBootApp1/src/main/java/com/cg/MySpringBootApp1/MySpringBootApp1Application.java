package com.cg.MySpringBootApp1;

import javax.websocket.server.PathParam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

//@SpringBootApplication

@Configuration
@EnableAutoConfiguration
@ComponentScan
public class MySpringBootApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(MySpringBootApp1Application.class, args);
	}
	

}





/*

@RestController
public class MySpringBootApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(MySpringBootApp1Application.class, args);
	}
	//GET ,POST,PUT,DELETE
	@RequestMapping(value="/hello/{name}",method=RequestMethod.GET) //url client call
			public String  sayHello(@PathVariable String name ) {
			{
			   return "Welcome to Spring Boot"+name;
			}
			}

}


*/