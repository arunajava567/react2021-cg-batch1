package com.cg.MySpringBootApp1.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoanController {
	
	@GetMapping("/getemi/{amount}") //rest endpoint, rest URL client communicate with server
	public String getEmiDetails(@PathVariable Double amount) {
		double emi=amount/12;
		return "EMI Amount is : Rs "+emi;  // invoke service, dao, db, read,update,delete
	}
	
	@GetMapping("/sample")
	public String getSampleMessage() {
		return "Sample message ";
	}
	

}
