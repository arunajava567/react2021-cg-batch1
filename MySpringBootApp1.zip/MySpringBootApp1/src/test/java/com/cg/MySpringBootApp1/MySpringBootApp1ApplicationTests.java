package com.cg.MySpringBootApp1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringBootApp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
