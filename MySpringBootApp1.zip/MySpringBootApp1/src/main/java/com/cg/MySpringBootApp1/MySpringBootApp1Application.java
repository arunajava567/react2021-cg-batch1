package com.cg.MySpringBootApp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MySpringBootApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(MySpringBootApp1Application.class, args);
	}

}
