package com.cg.bms.service;

import com.cg.bean.Book;

public interface BookService {
	
	public void addBook(Book book);

}
