package com.capgemini.lesson6.samepackage;

public class Executor {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Derived d=new Derived();
		Unrelated u=new Unrelated();
	}

}
