CREATE SEQUENCE student_sequence
start 1000
increment 1;