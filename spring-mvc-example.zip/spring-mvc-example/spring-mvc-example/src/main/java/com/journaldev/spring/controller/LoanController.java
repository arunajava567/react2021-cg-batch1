package com.journaldev.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller  //("/loan")
public class LoanController {
//	@RequestMapping(value="/getemi",method=RequestMethod.GET)
//	public String getEmi((@PathParam(name = "amount") Integer amount,Model model) {
	@GetMapping("/getemi")
	public ModelAndView getEmi(Model model) {
			return new ModelAndView("loan","emi",8000.00);
		
			//model.addAttribute("emi",amount);
		//return "loan";
	}

}
