package accosiation;
//HAs a Relation    //not  inheritance 
//not in a hierarchy   ,, composition

public class Account {
	 int accNumber;
	 String accHolderName;
	 Account() {}
	 
	public Account(int accNumber, String accHolderName) {
		this.accNumber = accNumber;
		this.accHolderName = accHolderName;
	}


	public int getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}
	public String getAccHolderName() {
		return accHolderName;
	}
	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}
	 
	
	
	
	
	
	
	
	

}
