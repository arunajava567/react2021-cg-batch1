package accosiation;
import java.util.*; 
public class Test {

	
	static String func(Object x, Object y) {
		return (x == y) + " " + x.equals(y) + " " + (x.hashCode() == y.hashCode());
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List l = new ArrayList();
		l.add("A"); l.add("B"); l.add("C"); l.add("D"); l.add("E"); ListIterator i = l.listIterator();
		i.next(); i.next(); i.next(); i.next(); i.remove();
		i.previous(); i.previous(); i.remove(); System.out.println(l);
        Object o1=new Object();
        Object o2=new Object();
		System.out.println(func(o1,o2));
		HashSet h=new HashSet();
		h.add(null);
		System.out.println(h);
	/*	LinkedHashMap l=new LinkedHashMap();
		l.put(null,90);
	System.out.println(l);
		 { List list = new ArrayList(); list.add("1");
		list.add("2");
		list.add(1, "3");
		List list2 = new LinkedList(list); 
		list.addAll(list2);
		list2 = list.subList(2, 5); list2.clear();
		 System.out.println(list);
		}*/
		
	}

}
