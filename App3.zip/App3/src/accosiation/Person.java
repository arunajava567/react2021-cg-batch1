package accosiation;
//Has A Relation 
public class Person {
	String name;
	int age;
	Account account; //embeding one class in to anothe rclass is called 
	                 // composition or association
	                 //has a relation   Person has Account
	
	Person () {}

	public Person(String name) {
		super();
		this.name = name;
	}

	public Person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
		
	}
	

}


