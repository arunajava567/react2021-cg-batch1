package test.set9;

import java.util.TreeMap;

public class Source {
	TreeMap<String,String> tm=new TreeMap<String,String>();
	
	
	String getNumber(String name) {
		return null;
	}
	boolean getName(String number ){
		return true;
	}
	public Source(TreeMap<String, String> tm) {
		super();
		this.tm = tm;
	}
	void print(TreeMap<String, String> tm) {
		
	}

}
