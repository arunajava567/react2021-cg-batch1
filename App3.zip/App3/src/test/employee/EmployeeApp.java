package test.employee;
class Employee{
	
	String empName;
	String empId;
	String empDept;
	int salary;
	public Employee(String empName, String empId, String empDept, int salary) {
		super();
		this.empName = empName;
		this.empId = empId;
		this.empDept = empDept;
		this.salary = salary;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpDept() {
		return empDept;
	}
	public void setEmpDept(String empDept) {
		this.empDept = empDept;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	
}

public class EmployeeApp {
 public Employee  getEmployeeInfo(String str) {
	 
	 String name=str.split("ID")[0];
	 name=name.replace("."," ");
	 String empID=str.split("ID")[1].split("DT")[0];
	 
	 String dept=str.split("ID")[1].split("DT")[1].split("CTC")[0];
	 String salary=str.split("ID")[1].split("DT")[1].split("CTC")[1];
	 salary=salary.replace("L", "");
	 int sal=Integer.parseInt(salary)*100000;
	 Employee emp=new Employee(empID,name,dept,sal);
	 return emp;
	 
 }
 public String getEmployeeTaxSlab(Employee e) {
	 String slab=null;
	 if(e.getSalary()>1000000)
		 slab="High";
	 else if(e.getSalary()>800000)
		 slab="Medium";
	 else if(e.getSalary()>500000)
		 slab="Low";	
	 else
		 slab="None";
	 return slab;
 }
}
