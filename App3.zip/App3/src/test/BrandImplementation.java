package test;

import java.util.*;
import java.util.stream.Collectors;

class Brand {
	String model;
	int speed;
	
	
	public Brand(String model, int speed) {
		super();
		this.model = model;
		this.speed = speed;
	}
	@Override
	public String toString() {
		return "Brand [model=" + model + ", speed=" + speed + "]";
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	
}
class BrandImplementation {
  List<String> getModelName(List<Brand> list) {
	  List<String> names=list.stream()
			  .map(Brand::getModel)
			  .collect(Collectors.toList());
			return names;  
  }
  Brand getModelDetails(List<Brand> list,String model,int speed) {
	  Optional<Brand> brand=list.stream().filter( b -> b.getModel().equals(model) && b.getSpeed()==speed).findFirst();
	  return brand.get();
  }
public static void main(String[] args) {
	List<Brand> list=new ArrayList<>();
	list.add(new Brand("SUV",500));
	list.add(new Brand("SEDAN",800));
	BrandImplementation b=new BrandImplementation();
	System.out.println(b.getModelName(list));
	System.out.println(b.getModelDetails(list,"SUV",500));
	
}

}
