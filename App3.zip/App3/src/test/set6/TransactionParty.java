package test.set6;

public class TransactionParty {
	String seller;
	String buyer;
	
	public TransactionParty(String seller, String buyer) {
		super();
		this.seller = seller;
		this.buyer = buyer;
	}
	public String getSeller() {
		return seller;
	}
	public void setSeller(String seller) {
		this.seller = seller;
	}
	public String getBuyer() {
		return buyer;
	}
	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}
	

}
