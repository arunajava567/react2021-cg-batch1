package test.set6;

import java.util.ArrayList;
import java.util.Collections;

public class Source {
int sum(ArrayList<Integer> numbers)
{   int sum=0;
	for(int i=0;i<numbers.size();i++)
	sum+=numbers.get(i);
	return sum;
}
public ArrayList<Integer> splitAndReverse(ArrayList<Integer> list) {
	int size=list.size();
	ArrayList list1=new ArrayList();
	ArrayList list2=new ArrayList();
	
	//System.out.println(size);
	if(size%2!=0) {
	for(int i=0;i<size/2+1;i++)
		list1.add(list.get(i));
	}
	else 
	    {
		for(int i=0;i<size/2;i++)
			list1.add(list.get(i));
		}
	Collections.sort(list1);
	if(size%2!=0) {
	for(int i=size/2+1;i<size;i++)
		list2.add(list.get(i));
	}
	else
	{
		for(int i=size/2;i<size;i++)
			list2.add(list.get(i));

	}
		
	Collections.sort(list2);
	
	list1.addAll(list2);
	return list1;
}
public Integer getItemAtIndex(ArrayList<Integer> list,int n) {
	return list.get(n);
}

public static void main(String[] args) {
	Source s=new Source();
	ArrayList list=new ArrayList();
	list.add(73);
	list.add(24);
	list.add(10);
	list.add(15);
	list.add(5);
	
	System.out.println(s.sum(list));
	System.out.println(s.getItemAtIndex(list,2));
	System.out.println(s.splitAndReverse(list));
}
}
