package test.set6;

public class IllegalAgeException extends Exception{
	IllegalAgeException(String msg) {
		super(msg);
	}

}
