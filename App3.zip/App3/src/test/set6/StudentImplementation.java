package test.set6;
import java.util.List;

 class Student {
	String name;
	Integer roll;
	Integer score;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getRoll() {
		return roll;
	}
	public void setRoll(Integer roll) {
		this.roll = roll;
	}
	public Integer getScore() {
		return score;
	}
	public void setScore(Integer score) {
		this.score = score;
	}
	public Student(String name, Integer roll, Integer score) {
		super();
		this.name = name;
		this.roll = roll;
		this.score = score;
	}
	

}

public class StudentImplementation {
List<Student> sort(List<Student> list){
	return list;
}
//Scholarship   >= 95 <=100  scheme a
//               >= 90 <=95  scheme b
}
