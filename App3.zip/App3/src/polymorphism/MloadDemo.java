package polymorphism;

class Mload
{// method overloading , static , compiletime ,within class
	//function name is same,but parameters are allways differ
	final int calArea(int s)
	{
		return s*s;
	}
	
	int calArea(int l,int b)
	{
		return l*b;
	}
	
	double calArea(double r) {
		return 3.142*r*r;
	}
	
	
}


public class MloadDemo {
	
	public static void main(String[] args) {
		
	
	Mload m=new Mload();
	System.out.println(m.calArea(5));
	System.out.println(m.calArea(5,2));
	System.out.println(m.calArea(5.23));
	
}
	
}
