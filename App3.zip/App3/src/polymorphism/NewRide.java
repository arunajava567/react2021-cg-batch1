package polymorphism;

public class NewRide extends Mride1{

	int getsq(int r)
	{
		return 324*234*r*r;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NewRide nr=new NewRide();
		System.out.println(nr.getsq(6));
	}

}
