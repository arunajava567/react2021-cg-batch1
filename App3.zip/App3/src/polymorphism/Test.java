
package polymorphism;


//overloading,overring, 



// Access modifier
//static ,final,sychronized,volatile,transcient,strictfp,abstract,native

//final 
class A
{  private int x;
double temp;
float xf=987.232f;
   int y;
   protected int z;
   
  // final 
   synchronized public  void show()
	{
		  System.out.println("superclass");
		
	}
	
 
}
class B extends A
{
	void show()
	{
		  System.out.println("sub class");
		
	}
}

class C
{
	void show()
	{     A a1=new A();
		  System.out.println(a1.z);
		
	}
}
public class Test {
	static int x=10;  // class , compiletime 
	final  int y;  //vraible 
	
	Test()
	{
		y=78;
	}
	void show()
	{
		System.out.println(x);
	}
	 static public void main(String[] args) {
		
		System.out.println(x++);  //static 
		Test t=new Test();
		System.out.println(t.y);//instance 
	
	}

}
