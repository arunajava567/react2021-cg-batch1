package java8lambdafunctionalinterfaces;

// static methods , default methods allowed
interface arith {
	
	public int sum(int a,int b); //abstract
	
	default void show() {
		System.out.println(" My java8interface default method");
	}
	
	static void disp() {
		System.out.println(" My Organization is Capgemini");
	}
	
}
interface arith1 {
	
	public int diff(int a,int b); //abstract
	
	default void show() {
		System.out.println(" My java8interface default method222222222222");
	}
	
	static void disp() {
		System.out.println(" My Organization is Capgemini222222222222222");
	}
	
}

class sub1 implements arith,arith1 {
	@Override
	public int sum(int a,int b) {
		return a+b;
	}
	public int diff(int a,int b) {
		return a-b;
	}
	public void show() {
		arith.super.show();
		arith1.super.show();
		arith.disp();
		arith1.disp();
		System.out.println(" My java8interface default method222222222222");
	}
}

public class Java8Interfacedemo {

	public static void main(String[] args) {
		sub1 s1=new sub1();
		System.out.println(s1.sum(3, 4));
		s1.show();  //using object
		arith.disp();  //intreface name
		System.out.println(s1.diff(8, 4));
		
	}

}
