package java8lambdafunctionalinterfaces;

@FunctionalInterface   //java8 single method
interface Loan {
	public int calc(int a);
	//pubic int sum(int a,int b);
}
// dont need to take a subclass to implement interface 
@FunctionalInterface   //java8 single method
interface Message {
	public void sayHello(String msg);
	//pubic int sum(int a,int b);
}
public class functionalInterfaceDemo  {
	public static void main(String[] args) {
	//	Loan l=  (int a) ->{ return a*a; };  //lambda
		Loan l=  (a) -> a*a;
		//	Loan l1= (int x) ->{ return x*x*x; };
		Loan l1= (x) -> x*x*x;
		System.out.println(l.calc(3));
		System.out.println(l1.calc(6));
		Message m=(String x) -> System.out.println(x);
		m.sayHello("Welcome to functional interfaces ");
	}
}
