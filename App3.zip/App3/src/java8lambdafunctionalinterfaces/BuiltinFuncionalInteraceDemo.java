package java8lambdafunctionalinterfaces;

import java.util.Random;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

/*   Consumer
     Supplier
      Predicate
     Function
*/
public class BuiltinFuncionalInteraceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Consumer<Integer> inverter = n -> System.out.println(-n);
	    inverter.accept(-35);
	    
	    int age=35;
	    
	    Consumer<Integer> addage= a->  System.out.println(a);
	    
	    addage.accept(age);
	    
	    Consumer<Integer> mult10 = n -> System.out.println(n*10);
	    mult10.accept(5);
	    
	    int x=90;
	    Supplier<Integer> supplier = () -> x/10;
	    
	    System.out.println(supplier.get());
	    
	    
	    Predicate<Integer> isEven = num1 -> num1 % 2 == 0;
	    if(isEven.test(15))
	    	System.out.println("Even");
	    else
	    	System.out.println("Odd");
	    
	    Predicate<Integer> isOdd = num1 -> num1 % 2 != 0;
	    
	    Function<Integer, Integer> square = num -> num * num;
	    System.out.println(square.apply(8));
	    
	    Function<Integer, Double> sumofsquares = n -> n*50.456; 
	    System.out.println(sumofsquares.apply(60));
	    
	    Function<String,Integer> findLength= s -> s.length();
	    System.out.println(findLength.apply("Capgemini"));
	    
	    BiFunction<String,String,Boolean> findEquals= (s1,s2) -> s1.equals(s2);
	    System.out.println(findEquals.apply("CG","CG123"));
	  
	    
	}

}
