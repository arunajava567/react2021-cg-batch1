package com.cg;

public class Person {   // public  protected default private 
	
	public int id;
	protected String pname;
	 String address;
	
	public Person()
	{
		id=34;
		pname="CGUser";
		address="HYD";
	}
	
	
	void show()
	{
		
	}
	@Override
	
	public String toString() {
		return "Person [id=" + id + ", pname=" + pname + "]";
	}
	

	
	
}
