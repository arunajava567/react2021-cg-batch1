package com.cg;

public class OutreDemo1 {
	int x;
	
	class Inner1{  //member inner class
		
	}
	
	void show()
	{
		
		  class Inner2{   //locla inner class
			  
		  }
		
	}
	
	
	static class Inner3 {
		
	}

	
	
	
}

