//1  custom package
package com.cg;

//import java.lang.String;

import java.util.Date;
//2  java.lan,  java.util,java.sql,java.io,java.awt,javax......
// libraries 
import java.util.Scanner;  // not good practice 

//import com.cg.arrays.student;

//import com.cg.arrays.ArrayDemo;
//3 interface
//4 class

 class student{
	
	
	int sid;
	String snmae;
	public student() {
		
	}
	
}
public  class DeclarationApp {

	public static void main(String[] args) {
		Date d=new Date();
		System.out.println(d.getDate()  +"  "+ d.getTime()  +"  "+d.getYear());
		
		Scanner sc=new Scanner(System.in);
		String name=sc.next();
		System.out.println(name);
		com.cg.arrays.ArrayDemo ar=new com.cg.arrays.ArrayDemo();
		
		
		String cname="Capgemini";
		
		Person p=new Person();
		System.out.println(p.id   +"  "+p.pname);
		
		System.out.println(p);  // invoke the object it  calls toString() display content
		
		
		student s=new student();
		
		com.cg.arrays.Employee e=new com.cg.arrays.Employee();
		
	   System.gc();

	}

}
