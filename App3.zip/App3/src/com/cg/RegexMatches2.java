package com.cg;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class RegexMatches2 {




	   private static final String REGEX = "foo";
	   private static final String INPUT = "foo ooooooooooooooo";
	   private static Pattern pattern;
	   private static Matcher matcher;

	   public static void main( String args[] ) {
	      pattern = Pattern.compile(REGEX);
	      matcher = pattern.matcher(INPUT);

	      System.out.println("Current REGEX is: "+REGEX);
	      System.out.println("Current INPUT is: "+INPUT);
System.out.println(matcher.find());
	      System.out.println("lookingAt(): "+matcher.lookingAt());
	      System.out.println("matches(): "+matcher.matches());
	   }
	}

/*
private static String REGEX = "dog";
private static String INPUT = "The dog says meow. " + "All dogs say meow.";
private static String REPLACE = "cat";

public static void main(String[] args) {
   Pattern p = Pattern.compile(REGEX);
   
   // get a matcher object
   Matcher m = p.matcher(INPUT); 
   INPUT = m.replaceAll(REPLACE);
   System.out.println(INPUT);

*/

/*
private static String REGEX = "a*b";
private static String INPUT = "aabfooaabfooabfoob";
private static String REPLACE = "-";
public static void main(String[] args) {

   Pattern p = Pattern.compile(REGEX);
   
   // get a matcher object
   Matcher m = p.matcher(INPUT);
   StringBuffer sb = new StringBuffer();
   while(m.find()) {
      m.appendReplacement(sb, REPLACE);
   }
   m.appendTail(sb);
   System.out.println(sb.toString());
*/
