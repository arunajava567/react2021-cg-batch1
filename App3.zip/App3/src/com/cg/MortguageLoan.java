package com.cg;
//multilevel
public class MortguageLoan extends PersonalLoan {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MortguageLoan m=new MortguageLoan();
		m.
	}

}
