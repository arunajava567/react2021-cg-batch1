package com.cg;

import java.util.Scanner;


class Address{
	
}
public class PersonApp {  //Dependency injection, composition 

	//client app , test application , running appp , end user application
	public static void main(String[] args) {
		
		//frist level encapsulation
		Customer c=new Customer(20,"asdasdasd",45645.435);   //compiletime 
		//c.cid=101;   //not  agood practice
		
		c.setCid(101);   //runtime 
		c.setCommision(98);
		c.setName("ram");
		
		System.out.println(c.getCid()+""+c.getName() +"   "+c.getCommision());
		
		System.out.println(c);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*
		Person p=new Person();
		
		System.out.println(p);   //toString()
		
		System.out.println(p.id+"  "+p.pname);
		
		Scanner sc=new Scanner(System.in);
				
			System.out.println("enter person details");	
		p.id=sc.nextInt(); sc.nextLine();
		p.pname=sc.nextLine();
		
		System.out.println(p.id+"  "+p.pname +" "+p.address);
		
		
//public , default,protected are accessible  within your package */
	}

}
