package com.cg;
public class Product {
	int pid;  //instance variable vary from object to object
	String name;
	double qty;
 public static String mname="SONY";  // will not vary from object to object 
	
 static{
	 System.out.println("in static ....");
 }
 
	{  //instance block
		System.out.println("instance block");
		calcPrice();
	}
	static void disp()
	{
		System.out.println("display static function ");
	}
	public Product() {  //empty constructor iwthout params
		System.out.println("in constructor");
		pid=90;
		name="Bag";
	    qty=200.00;
	}	
	public Product(int pid, String name) {
		System.out.println("in constructor");
		this.pid = pid;
		this.name = name;
	}
	public Product(int pid, String name, double qty) {
		System.out.println("in constructor");
		
		this.pid = pid;
		this.name = name;
		this.qty = qty;
	}

	@Override
	public String toString() {
		return "Product [pid=" + pid + ", name=" + name + ", qty=" + qty + "]";
	}

    double calcPrice()  //member function method 
    {
    	return this.qty*50;  // business calculaion
    }



	public static void main(String[] args) {
		System.out.println("in main....");
		Product p=new Product(); // JVM    type default 
   System.out.println(p.pid +"  "+p.name);
   System.out.println(p);
   Product p1=new Product(98,"Book"); // JVM    type default 
   System.out.println(p1.pid +"  "+p1.name);
   System.out.println(p1);
   
   
   Product p2=new Product(92,"BookShelf",70); // JVM    type default 
     System.out.println(p2);
     System.out.println(p2.calcPrice());
   
  System.out.println(Product.mname);//in other class
  Product.disp();   //in other class
  disp();   //within class
  System.out.println(mname);
  
	}






}
