package com.cg;
/// sub class   , child class, derived class
public class PersonalLoan  extends Loan  {  //extends
	                                       // PersonalLoan is a Loan
	   double amount;
	   double interestRate;
	   String bname; //branchname
	   
	   
        @Override
	public String toString() {
		return "PersonalLoan [amount=" + amount + ", interestRate=" + interestRate + "]";
	}
  
		public PersonalLoan(int id, String cname, String bname, double amount, double interestRate) {
		super(id,cname,bname);
		this.amount = amount;
		this.interestRate = interestRate;
	}
  void show()
  {   super.show();
	  System.out.println("Personla loan");
  }
     void dispPersonalLoanDetails()
     {    super.show(); 
    	 this.show();
	
    	 System.out.println(super.bname+"   "+this.bname);
    	 System.out.println(" Interest rate for PersonalLoan:"+this.interestRate );
    	
    	
     }
     
     
		//  reusability : no need to redefine which is avialble in super class not required
	public static void main(String[] args) {
		/*Loan l=new Loan(101,"Ram","ICICI");
		
		System.out.println(l);*/
		
		PersonalLoan pl=new PersonalLoan(102,"Kiran","ICICI",789999.89,7.9);
		System.out.println(pl.id+"  "+pl.cname+"   "+pl.bname +"  "+pl.amount+"  "+pl.interestRate);
		
		pl.dispPersonalLoanDetails();
		pl.dispLoanDetails();
		pl.show();  
		System.out.println(pl instanceof PersonalLoan);
		

	}

}
