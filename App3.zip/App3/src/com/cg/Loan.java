package com.cg;

//super class   ,parent class, base class
public class Loan {

	
	 int id;
	 String cname;
	 String bname;
	 
	public Loan(int id, String cname, String bname) {
		super();
		this.id = id;
		this.cname = cname;
		this.bname = bname;
	}
	
	void dispLoanDetails(){
		
		System.out.println(" Bank name : Loan  " +bname);
		
		
	}
	void show()
	{
		System.out.println("loan");
	}
 
	@Override
	public String toString() {
		return "Loan [id=" + id + ", cname=" + cname + ", bname=" + bname + "]";
	}
	 
	 
}
