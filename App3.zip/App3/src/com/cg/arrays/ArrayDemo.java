package com.cg.arrays;

public class ArrayDemo {
	int a[]= {3,4,5,6};

}
