package com.cg.arrays;

public class student{
	
	
	int sid;
	String snmae;
	public student() {
		
	}
	
}