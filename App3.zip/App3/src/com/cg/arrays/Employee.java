package com.cg.arrays;

public class Employee {

	public String name;
}
