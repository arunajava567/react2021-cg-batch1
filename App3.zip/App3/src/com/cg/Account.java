package com.cg;

public class Account {
	
	 int acNumber;
	 double balance;
	 String cname;
	 
  void show()
  {
	  
  }
}
