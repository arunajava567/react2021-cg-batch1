package com.cg;

import java.util.Date;

//Object   -- java.lang

//implicit
//Object  all utility of java class 
// getClass()   , toString() ,equals() , hashcode() , finalize(),clone(), 
// wait(), notify(),notifyAll()


//syntax
class Product1 implements Cloneable
{
	int id;
	String pname;
	/*Product1() {
		
	}*/
	public Product1(int id, String pname) {
		
		this.id = id;
		this.pname = pname;
	}
	@Override
	public String toString() {
		return "Product1 [Id of Product=" + id + ", Productname=" + pname + "]";
	}
	//opitonal JVM  ... releasing of resouces 
	public void finalize() {
		this.id=0;
		this.pname=null;
	}
	// syntax
	public Object clone() throws CloneNotSupportedException
	{
		return super.clone(); // super...Object
	}
	
	
}
public class ObjectDemo {

	public static void main(String[] args) throws CloneNotSupportedException{
		
		//creation
		Object o=new Object();  // 
		
		String cname="Capgemini";  // object
		
		Date d=new Date();
		
		Product1 p=new Product1(10,"Box");
		Product1 p1=new Product1(11,"Box123");
		Product1 p2=p1; //reference
		
		System.out.println(d.getClass()+"  "+ cname.getClass()+"  "+ p.getClass() );
		
		System.out.println(p);
		System.out.println(p.hashCode()+"  "+p1.hashCode());
		System.out.println(p.equals(p1));
		
		System.out.println(p2.equals(p1));
		
 		// thread wait(), notify(),notifyall() 
		//not from Thread   .. Object
		
		Product1 p3=(Product1)p1.clone(); //prototyping
		
		System.out.println(p1);
		System.out.println(p3);
		System.out.println(p1.hashCode()+"  "+p3.hashCode());
		
		
		Object o1=new Product1(20,"table");
	       Object a1=new Account();	
		//System.gc();//

	       
	       int age=20;   //value
	       
	       Integer agObj=new Integer(25);  //object  boxing
	       Integer i1=new Integer("56");
	       
	       int agval=agObj.intValue(); //unboxing
	       int agval1=agObj;
	       System.out.println(agObj.intValue()+10);
		      
	       System.out.println(agObj+10);//    autoBoxing autoUnboxing
	      //boxing  /Unboxing
	       
	}

}

class Account{
	
}
