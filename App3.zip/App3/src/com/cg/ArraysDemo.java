package com.cg;

//sorting and searching in an array 
//Arrays class
import java.io.*;

import java.util.Arrays;
import java.util.List;
public class ArraysDemo
{
	public static void main(String s[]) throws IOException
	{
		int arr[] = {33,4,32,62,73,8,5};
		int arr1[] = {33,4,32,8,5};
		
		System.out.println(Arrays.equals(arr, arr1));
		List l1= Arrays.asList(arr); //list
		
		System.out.println(l1);
		
		for(int x:arr)
			System.out.println(x);
		
		
		Arrays.sort(arr);
		
		for(int x:arr)
			System.out.println(x);
				
		int index = Arrays.binarySearch(arr,8);
		System.out.println("Location of "+(index+1));
		Arrays.fill(arr, 10);
		for(int x:arr)
			System.out.println(x);
		
		
		int a[]= {2,1,3,4,5,6,7};
		int dest[]=new int[3];
		
		System.arraycopy(a, 0, dest,  0, 3);
		for(int x:a)
			System.out.print(x +"  ");
		System.out.println();
		for(int x:dest)
			System.out.print(x+" ");
		
		
		int x=99;
		double d=x;
		double sal=8787.879;
		int sal1=(int)sal;
		
	}
}