package com.cg;


class A{
	int a;
	
	A()
	{
		a=10;
	}

	public A(int a) {
		
		this.a = a;
	}
	
	
}

class B extends A
{int a;
  void show() {
	  System.out.println(super.a +"  "+this.a);
  }
	
}
public class ThissuperDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a1=new A1(4);

	}

}
