package com.exceptions.exception;
//exception
public class DepositException extends Exception {  //Throwable, RuntimeException
	public DepositException (String msg)
	{
		super(msg);
	}
}
