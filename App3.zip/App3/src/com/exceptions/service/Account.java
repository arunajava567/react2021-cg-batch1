package com.exceptions.service;

import com.exceptions.exception.DepositException;

//service
public class Account
{
	String name;
	static double balance=5000;
	
	public void withdraw(double withdrawAmount)
	{
		balance-=withdrawAmount;
	}
	public void deposit(double depositAmount)  throws DepositException
	{   if(depositAmount<1000)
		 throw new DepositException("Minimum deposit should be 1000.00");
	else
		balance+=depositAmount;
	}
	public double getBalance()
	{
		return balance;
	}
	
}
