package abstraction;

import java.util.StringTokenizer;

public class StringTokenizerDemo {

	public static void main(String[] args) {
		
		String line="Capgemini Hyderabad Talangana India";
		StringTokenizer st=new StringTokenizer(line);
		
		while(st.hasMoreTokens())
		{   String token=st.nextToken();
			System.out.println(token.toUpperCase()+"  "+token.length());
		}
		
		String tokens[]=line.split(" ");
		
		for(String t: tokens)
		{
			System.out.println(t);
		}
		
	}

}
