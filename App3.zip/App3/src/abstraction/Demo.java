package abstraction;
class Foo
{
	int x;
	
	 Foo()
	 {
		 
	 }
	  // no of param,datatype should not smae , order not same 
	 int getNum(int a,int b,String firstName)
	 {    System.out.println("super class:"+firstName);
		 return a+b;
	 }
	 int getNum(String lastName ,int x, int  y) {
		 System.out.println(lastName);
		 return 10;
	 }
	 void disp()
	 {
		 System.out.println("disp...");
	 }
	
}

class Bee extends Foo
{   @Override
	int getNum(int x,int y,String cityName)
	{   System.out.println("in sub class...");
		return 20;
	}
	
	void show()
	{   
		System.out.println(getNum(4,5,"Ramu"));
		disp();
	}
}



public class Demo {

	public static void main(String[] args) {
		
		Foo f=new Foo();   // design patterns 
		Bee b=new Bee();
		b.show();
	}

}
