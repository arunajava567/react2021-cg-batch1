package abstraction;
//  cannot instantiated
interface  Loan
{   public static final String bankName="ICICI";
	// default abstract and public 
	 double getEmi(double amount); 
	 void dispLoanType();
	 static void show()  //java8
	 {
		 
	 }
	 default int add()  //java8
	 {
		 return 10;
	 }
	
}
// as multiple is not possible, multiple ab class .....
interface  Bank
{   public static final double pi=3.142;
     
}
//in case of implementing sub class methods access shoud be equal or stronger than
// super class method
// public- protected- default -private 
class HousingLoanImpl implements Loan,Bank {
	
	@Override
	public double getEmi(double amount) {
		return amount/20;
	}
	public void dispLoanType() {
		System.out.println("Hosuing Loan");
		
	}
	public  void bankDetails(){
		System.out.println(" bank loan");
	}
}

class VehicleLoanImpl implements  Loan,Bank  {
	// implementation
	@Override
	public double getEmi(double amount) {
		return amount/15;
	}
	public void dispLoanType() {
		System.out.println("vehicle Loan");
		
	}
	public void bankDetails()
	{
		
	}
	
	
}

public class AbstractDemo {
	public static void main(String[] args) {
       Loan l=new HousingLoanImpl();
       System.out.println(l.getEmi(50000));
       l.dispLoanType();
       Bank b=new HousingLoanImpl();
       b.bankDetails();
       l=new VehicleLoanImpl();
       System.out.println(l.getEmi(50000));
       l.dispLoanType();
       b=new VehicleLoanImpl();
       b.bankDetails();
      
       
       
       
   
	}

}
