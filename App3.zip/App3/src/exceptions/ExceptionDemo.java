package exceptions;
// compile ( checked ) ,  runtime(unchecked)

// Exception: is obnormal condition present in your code, program terminates

// Exception handling mechanism
//  1. try- catch  , try with multiple catch, nested try-catch, try-catch-finally
//  2. throws 
//  3. throw
public class ExceptionDemo {
	public static void main(String[] args) {
		
			   try {
				String name="Pooja";
				   System.out.println("REsult:"+name.substring(7,9));
			} catch (ArithmeticException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			  
	}
}
