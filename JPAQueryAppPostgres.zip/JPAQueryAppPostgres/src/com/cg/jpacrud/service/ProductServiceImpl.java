package com.cg.jpacrud.service;

import java.util.List;

import com.cg.jpacrud.dao.ProductDao;
import com.cg.jpacrud.dao.ProductDaoImpl;
import com.cg.jpacrud.entities.Product;

public class ProductServiceImpl  implements ProductService{
	ProductDaoImpl productDao=new ProductDaoImpl();
	public void addProduct(Product p) {
		System.out.println("in   service....");
		productDao.addProduct(p);
	}
	 public List<Product> listAllProducts(){
		 List<Product> plist=productDao.listAllProducts();
		 return plist;
	 }
	 public Product getProductById(int id) {
		 Product p=productDao.getProductById(id);
		 return p;
	 }
	 public void  deleteProduct(int id) {
		 productDao.deleteProduct(id);
	 }
	 public void  updateProduct(int id) {
		 productDao.updateProduct(id);
	 }
}
