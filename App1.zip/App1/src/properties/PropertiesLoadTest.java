package properties;
import java.io.*;
import java.util.Properties;

public class PropertiesLoadTest {
    public static void main(String[] args) {
	        try (InputStream input = new FileInputStream("E:\\CG\\TemplateApplication\\src\\properties\\dbconfig.properties")) {
	            Properties prop = new Properties();
	            // load a properties file
	            prop.load(input);
	            // get the property value and print it out
	            System.out.println(prop.getProperty("db.url"));
	            System.out.println(prop.getProperty("db.user"));
	            System.out.println(prop.getProperty("db.password"));
	            System.out.println(prop.getProperty("db.name"));


	        } catch (IOException ex) {
	            ex.printStackTrace();
	        }

	    }

	}