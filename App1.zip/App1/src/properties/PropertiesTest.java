package properties;
import java.io.*;
import java.util.Properties;

public class PropertiesTest {
	

	    public static void main(String[] args) {
          //java7
	        try (OutputStream output = new FileOutputStream("E:\\CG2021\\App1\\src\\properties\\dbconfig.properties"))
	        
	        {

	            Properties prop = new Properties();

	            // set the properties value
	            prop.setProperty("db.url", "localhost");
	            prop.setProperty("db.user", "cg");
	            prop.setProperty("db.password", "cg");
	            prop.setProperty("db.name", "healthassist");
	            


	            // save properties to project root folder
	            prop.store(output, null);

	            System.out.println(prop);

	        } catch (IOException io) {
	            io.printStackTrace();
	        }

	    }
	}