package com.cg.oops;

public class Employee {

}
