package com.cg.oops;

public class Customer {

}
