package com.cg.oops;

public class Manager {

	public static void main(String[] args) {
		
       
	}

}
