package com.cg.test;
import java.util.*;
import java.util.stream.Collectors;

class Brand {
	String model;
	int speed;
	
	
	public Brand(String model, int speed) {
		super();
		this.model = model;
		this.speed = speed;
	}
	@Override
	public String toString() {
		return "Brand [model=" + model + ", speed=" + speed + "]";
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	
}
class BrandImplementation {
	
  List<String> getModelName(List<Brand> list) {
	  List<String> l1 = new ArrayList<String>();
	  Iterator i=list.iterator();
	  while(i.hasNext())
	    {  
          String model=((Brand)i.next()).model;
          l1.add(model);
    }
      return l1;
		// return list with only bran names
	  
  }
  
  
  Brand getModelDetails(List<Brand> list,String model,int speed) {
	  Brand b=null;
	   for(int i=0;i<list.size();i++) {
           if(list.get(i).model==model && list.get(i).speed==speed)
           {
               b=list.get(i);
           }
       }
	   return b;
	  //rteurn a brand object for hwich mode and speed is matched
  }
public static void main(String[] args) {
	List<Brand> list=new ArrayList<>();
	list.add(new Brand("SUV",500));
	list.add(new Brand("SEDAN",800));
	
	
	
	BrandImplementation b=new BrandImplementation();
	System.out.println(b.getModelName(list));
	System.out.println(b.getModelDetails(list,"SUV",500));
	
}

}


/*
 * 
 * 
 *  List<String> getModelName(List<Brand> list) {
	  List<String> names=list.stream()
			  .map(Brand::getModel)
			  .collect(Collectors.toList());
			return names;  
  }
  
  
  Brand getModelDetails(List<Brand> list,String model,int speed) {
	  Optional<Brand> brand=list.stream().filter( b -> b.getModel().equals(model) && b.getSpeed()==speed).findFirst();
	  return brand.get();
  }
 * 
 * 
 * */
