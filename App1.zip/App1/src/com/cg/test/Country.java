package com.cg.test;
import java.util.*;
import java.util.Map.Entry;
	class Country{
		HashMap<String,String> countryMap=new HashMap<String,String>();
		HashMap<String,String> worldMap=new HashMap<String,String>();
		public HashMap<String,String> addCountryCapital(String country,String capital) {
		//	HashMap<String,String> countryMap1=new HashMap<String,String>();
			countryMap.put(country, capital);
			return countryMap;
		}
		String getCapital(String country) {
			return countryMap.get(country);
		}
	    String getCountry(String capital) {
		String country1=null;
			Set s=countryMap.entrySet();
			Iterator i=s.iterator();
			while(i.hasNext()) {
				Entry e=(Entry)i.next();
				if( e.getValue() ==capital)
					country1=(String)e.getKey();
			}
			return country1;
		}
	    HashMap<String,String> swapKeyValue() {
	    	Set s=countryMap.entrySet();
			Iterator i=s.iterator();
			while(i.hasNext()) {
				Map.Entry e=(Map.Entry)i.next();
			   	worldMap.put((String)e.getValue(), (String)e.getKey());
			}
			return worldMap;
	    }
		public static void main(String[] args) {
			Country c=new Country();
			c.addCountryCapital("United Kingdom", "Londan");
			c.addCountryCapital("India", "New Delhi");		
			System.out.println(c.getCapital("India"));
			System.out.println(c.getCountry("Londan"));
			System.out.println(c.swapKeyValue());
		}

	}
	 