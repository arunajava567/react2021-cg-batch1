package com.cg.io;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
public class ConsoleDemo {
public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
	//	DataInputStream dis=new DataInputStream(System.in);
	
	//    String name=dis.readLine();
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("enter name");
		//String name=dis.readLine(); //deprecated 
		
		String name=br.readLine();
		System.out.println("Name is :"+name);
		
	}

}
