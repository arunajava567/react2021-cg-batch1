package com.cg.io;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
class Account  implements Serializable   //marker interfaces , Cloneable 
{Integer acNo;
	String name;
	Double balance;
	@Override
	public String toString() {
		return "Account [acNo=" + acNo + ", name=" + name + ", balance=" + balance + "]";
	}
	public Integer getAcNo() {
		return acNo;
	}
	public void setAcNo(Integer acNo) {
		this.acNo = acNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	public Account(Integer acNo, String name, Double balance) {
		super();
		this.acNo = acNo;
		this.name = name;
		this.balance = balance;
	}
}
public class AccountDemo {
	public static void main(String[] args) throws IOException,ClassNotFoundException {
		Account a1=new Account(101,"Ram",8000.00);
		FileOutputStream fout=new FileOutputStream("e:\\serial");
		ObjectOutputStream out= new ObjectOutputStream(fout);
		out.writeObject(a1);  //serialization
		FileInputStream fin=new FileInputStream("e:\\serial");
		ObjectInputStream oin=new ObjectInputStream(fin);
		Account a2=(Account)oin.readObject();  //deserialization
		System.out.println(a1+"   "+ a1.hashCode());
		System.out.println(a2+"   "+a2.hashCode());
	}
}
