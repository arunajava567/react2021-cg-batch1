package com.cg.io;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class FileDemo1 {
	public static void main(String[] args) throws IOException
	{
		// byte stream
		//	FileInputStream f1 = new FileInputStream("e:\\abc.txt");
			
			
		//	FileOutputStream f2=new FileOutputStream("e:\\abcout.txt");
		
		//char streams,  filter stream 
		FileReader  f1 = new FileReader("e:\\abc.txt"); 
		BufferedReader b1=new BufferedReader(f1);  //filter  lilenumberinputstream, encryption....
		FileWriter f2=new FileWriter("e:\\abcout1.txt");
		BufferedWriter b2=new BufferedWriter(f2);    //
			//int k; 
		String line=null;
			while((line=b1.readLine())!=null)
			{System.out.print(line);
			b2.write(line);
			}
				b1.close();
				f1.close();   // checked exception
				b2.close();
				f2.close();
	}
}
