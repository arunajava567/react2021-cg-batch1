package com.cg;
import java.util.Date;
import java.util.Scanner;
public class SampleApp2 {
	public static void main(String[] args) {
			/*Scanner sc=new Scanner(System.in);
		System.out.println("Enter A value");
		int a=sc.nextInt();
		*/
		
		String name="Nisha";
		//instanceof operator to check of type 
		System.out.println(name instanceof String);
		Date d=new Date();
		System.out.println(d instanceof Date);
		
		
		
	}
}
