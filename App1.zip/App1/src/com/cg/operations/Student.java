package com.cg.operations;

public class Student {

}
