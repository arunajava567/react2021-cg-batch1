package com.cg.operations;

import com.cg.oops.Loan;

class Demo {
	void disp() {
	Loan l=new Loan();
	
	}
	
}

public class EducationLoan extends Loan {

	public static void main(String[] args) {
		EducationLoan el=new EducationLoan();
		el.getLoanDetails();
		

	}

}
