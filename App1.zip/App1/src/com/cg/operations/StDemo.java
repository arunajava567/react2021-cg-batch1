package com.cg.operations;

import java.util.StringTokenizer;

public class StDemo {

	public static void main(String[] args) {
		String s="Ram-302-Hitechcicty-Hyderabad-Telangana";
		StringTokenizer st=new StringTokenizer(s,"-");
		while(st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
		System.out.println(" using split");
		String tokens[]=s.split("-");
		for(String s1:tokens) {
			System.out.println(s1);
		}
	}

}
