//sorting and searching in an array 
//Arrays class
package com.cg.arrays;
import java.io.*;
import java.util.*;

public class ArraysDemo
{
	public static void main(String s[]) throws IOException
	{
		int a[]= {3,2,1,4,2,7,8,9,2,1};
		for(int x: a) 
			System.out.println(x);
		Arrays.sort(a);
		
		System.out.println("after sorted elements:");
		
		for(int x: a) 
			System.out.println(x);
		
		System.out.println("Which element to search:");
		Scanner sc=new Scanner(System.in);
		int search = sc.nextInt();
		
		int index = Arrays.binarySearch(a,search);
		
		System.out.println("Location of "+search+":"+(index+1));
	
}}