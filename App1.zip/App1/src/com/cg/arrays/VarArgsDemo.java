package com.cg.arrays;

class Employee {
	
	int id;
	String name;
	
	Employee() {
		id=101;
		name="Ram";
	}
	
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + "]";
	}


	public Employee(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}


	Employee  processEmployee(Employee e) {
		this.id=e.id+10;
	   this.name=e.name.toUpperCase();
	  return  new Employee(this.id,this.name);
	}
	
	
}

public class VarArgsDemo
{
	
	//var args
	 int sum(String name,int... n)
	{
		int sum=0;
	
		for(int i=0;i<n.length;i++)
			sum = sum + n[i];

		return sum;	
	}
	public static void main(String[] args)
	{VarArgsDemo v=new VarArgsDemo();
		System.out.println(v.sum("a",10,20,30));

		System.out.println(v.sum("b",10,20,30,40,50));
		
		System.out.println(v.sum("c",10,20));
		
		System.out.println(v.sum("d",10,20,23,32));
		
		
		Employee e=new Employee();
		Employee e1=new Employee();
		
		System.out.println(e.processEmployee(e1));
		
		int a=10;
		
		Integer a1=new Integer(a);
		a1=null;
		
		Integer a2=a;  //10  auto boxing
		
		int avalue=a2.intValue(); //un boxing
		int avalue1=a2; //auto unboxing 
		
		System.gc();
		
		
	}
}