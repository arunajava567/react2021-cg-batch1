package com.cg.arrays;

class Course {
	int id;
	String title;
	@Override
	public String toString() {
		return "Course [id=" + id + ", title=" + title + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Course(int id, String title) {
		super();
		this.id = id;
		this.title = title;
	}
	
	
}
public class ArrayDemo {

	public static void main(String[] args) {

//homogeneous    int , float .....
		
		int marks[]=new int[10];  //declaration    int a[10];
		
		String  listOfCourses[]= {"Java","Spring","Webservices","DevOps"};//initialization
		
		for(int i=0;i<marks.length;i++) {
			System.out.println(marks[i]);
		}
		for(int mark : marks) {
			System.out.println(mark);
		}
		for(int i=0;i<listOfCourses.length;i++) {
			System.out.println(listOfCourses[i]);
		}
		for(String  course :listOfCourses) {
			System.out.println(course);
		}
		
		int s[]= {2,3,1,4,5,6,3,4,7,8,9};
		int d[]=new int[5];
		
		System.arraycopy(s,0,d,0,3);
		System.out.println(" source ...");
		for(int x : s) {
			System.out.print(x+"  ");
		}
		System.out.println();
		for(int x : d) {
			System.out.print(x+"  ");
		}
		
		System.out.println();
		int matrix[][]= {{3,4,2},{6,7,3},{5,6,7}};
		 for(int i=0;i<matrix.length;i++)
		 { for(int j=0;j<matrix[i].length;j++)
		 {
			 System.out.print(matrix[i][j]+" ");
		 }
		    System.out.println();
		 }
		
		 
		 System.out.println(" using for each loop");
		
		 for(int x[]:matrix)
		    { for(int y:x)
		        {System.out.print(y+" ");
		            
		        }
		        System.out.println();
		    }
		 
		 //array of objects 
		 Course course[]=new Course[5];
		course[0]=new Course(10,"Java");
		course[1]=new Course(11,"Oracle");
		course[2]=new Course(12,"Rest");
		course[3]=new Course(13,"Webservices");
		
		for(Course c :course) {
			System.out.println(c);
		}
		
	   
		
	}

}
