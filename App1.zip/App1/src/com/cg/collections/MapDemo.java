package com.cg.collections;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
public class MapDemo {
	public static void main(String[] args) throws ClassCastException  {
		//HashMap,LinkedHashMap allows null as key
		//TreeMap null are not allowed for keys  LinkedHahMap is ordered, TreeMap is sorted..
		Map<Integer,Object> m1=new HashMap<Integer,Object>();
		m1.put(4, 23);
		m1.put(5, 13);
		m1.put(null, 123);
		m1.put(1, 67);
		m1.put(3, 18);
		m1.put(2, 22);
		Map<Integer,String> m2=new HashMap<Integer,String>();
		
		List l1=new ArrayList();
		
	/*	//m1.put(null, "Capgemini");
		System.out.println(m1.getOrDefault(2, 20));
		System.out.println("Map====");
		System.out.println(m1);
		Set keys=m1.keySet();
		System.out.println(keys);*/
	//	ArrayList values=new ArrayList(m1.values());
		
	//	System.out.println(values);
	//	List l=(ArrayList)values;
		//Arrays.sort(values.toArray());
	//	Collections.sort(values);
		//System.out.println("sorted list :"+ values);
		
		Set entryset=m1.entrySet();
		Iterator it=entryset.iterator();
		while(it.hasNext()) {
			Entry m=(Entry)it.next();
			
			if((Integer)m.getValue()>18)
				l1.add(m.getKey());
				//m2.put((Integer)m.getKey(), "Gold");
				//else
				//	m2.put((Integer)m.getKey(), "Silver");
			
			
		}
		//System.out.println(m2);
		System.out.println(l1);
}

}
