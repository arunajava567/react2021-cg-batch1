package com.cg.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.TreeSet;

public class ComparableDemo {

	public static void main(String[] args) {
		//builtin sorted , when using custom objects , need spesify order of objects comparator , compare
		TreeSet<Employee> empSet=new TreeSet<Employee>(new NameComparator());
		
		//List<Employee> empSet=new ArrayList<Employee>();
		empSet.add(new Employee(301,"Ram"));
		empSet.add(new Employee(100,"Bindu"));
		empSet.add(new Employee(299,"Arun"));
		
	//	Collections.sort(empSet,new IdComparator());
		System.out.println(empSet);
		

	}

}
