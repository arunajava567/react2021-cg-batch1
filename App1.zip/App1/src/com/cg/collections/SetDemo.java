package com.cg.collections;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;
public class SetDemo {
		public static void main(String[] args) {
		//	Set<Object> l1=new HashSet<Object>();
		//	Set<Object> l1=new LinkedHashSet<Object>();
			//Set-> SortedSet ->TreeSet
			Set<Object> l1=new TreeSet<Object>();
			l1.add(223); l1.add(99); 
			l1.add(23); 
			l1.add(15);//autoboxing 
			l1.add(new Integer(23));//boxing
			l1.add(73);
			l1.add(83);
			System.out.println(l1);
			List<Object> l2=new ArrayList<Object>();
			l2.add(34);l2.add(56);l2.add(22);l2.add(67);
	}
}
