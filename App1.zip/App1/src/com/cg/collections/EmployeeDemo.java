package com.cg.collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class EmployeeDemo {
	
	static ArrayList<Employee> elist=new ArrayList<Employee>();
	void addEmployee(Employee e) {
		  elist.add(e);
		
	}
	void listEmployee() {
		Iterator<Employee> i=elist.iterator();
	     while(i.hasNext()) {
	    	 Employee e=(Employee)i.next();
	    	 System.out.println(e.id +"  "+e.name);
	}
	}
	     void deleteEmployee(int id1) {
	    	 Iterator<Employee> i1=elist.iterator();
		     while(i1.hasNext()) {
		    	 Employee e=(Employee)i1.next();
		    	 if(e.id==id1)
		    		 i1.remove();
		    	 } System.out.println("employee deleted");
	     }
	     
	     void updateEmployee(int id1,String name1) {
	    	 Iterator<Employee> i=elist.iterator();
		     while(i.hasNext()) {
		    	 Employee e=(Employee)i.next();
		    	 if(e.id==id1)
				    	e.name=name1;
		    	 
		     }
	         System.out.println("updated...");
	     }

	public static void main(String[] args) {
		int op=1;
		EmployeeDemo ed=new EmployeeDemo();
		Scanner sc=new Scanner(System.in);
		do {
		System.out.println("enter your option    1.add   2.delete   3.list all 4.update ");
		op=sc.nextInt();
		
		switch (op) 
		{
		case 1: { System.out.println("entre employee details");
		         int id=sc.nextInt(); sc.nextLine();
		         String name=sc.nextLine();
		         Employee e=new Employee(id,name);
		          ed.addEmployee(e);
		         break;
		}
		case 2: {System.out.println("entre employee id to be deleted");
                  int id1=sc.nextInt();
                  ed.deleteEmployee(id1);
		     break;
			}
		case 3: {	ed.listEmployee();
			    	break;
		}
		
		case 4: {System.out.println("entre employee id to be updated");
        int id1=sc.nextInt();sc.nextLine(); //clear buffer
        System.out.println("enter name to be updated");
        String name1=sc.nextLine();
        
        ed.updateEmployee(id1, name1);
		break;
	}
		
		}
		
		} while (op<=4);
		

	}

}
