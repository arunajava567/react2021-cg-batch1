import java.util.*;
import java.io.*;

public class ArrayToCollection{
	public static void main(String args[]) throws IOException{
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("How many elements you want to add to the array: ");
		int n = Integer.parseInt(in.readLine());
		String[] name = new String[n];
		for(int i = 0; i < n; i++){
			name[i] = in.readLine();
		}
		List<Integer> list = Arrays.asList(23,45,67,89,56); //Array to Collection
		System.out.println("Elements of the list: ");
		for(Integer li: list){
		
			System.out.print(li);
		}
		
		Collections.
	}
}
