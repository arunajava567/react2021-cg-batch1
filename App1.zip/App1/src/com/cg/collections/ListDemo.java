package com.cg.collections;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;

public class ListDemo {
	public static void main(String[] args) {
	//	Collection - >List -> ArrayList
	//	ArrayList l=new ArrayList();
	//	List<Object> l1=new ArrayList<Object>();
		
	//	LinkedList<Object> l1=new LinkedList<Object>();
		// addFirst(),addLast(),removeFirst(),removeLast(),peek(),poll()
		
		Vector<Object> l1=new Vector<Object>();//syncronized  , threadsafe , locking , slow
		//l1.capacity();
		//l1.ensureCapacity(minCapacity);
		
		l1.add(23);  //autoboxing 
		l1.add(new Integer(23));//boxing
		
		Integer x=(Integer)l1.get(0); //unboxing
		int xval=x.intValue();//
		
		
		l1.add(343.2323);
		l1.add("Capgemini");
		l1.add(new Date());
		//l1.add(new Employee());
		l1.add(23);
		l1.add(343.2323);
	
		l1.add(23);
		l1.add(343.2323);

		List<Object> l2=new ArrayList<Object>();
		
		l2.add(34);l2.add(56);l2.add(22);l2.add(67);
		
		System.out.println(l1.contains(343.2323));
		l1.addAll(l2);//interoperability
		
		System.out.println(l1.containsAll(l2));
		//l1.removeAll(l2);
		l1.retainAll(l2);
		System.out.println(l1);
		//l1.remove(2);
		System.out.println(l1.indexOf("Capgemini"));
		System.out.println(l1.isEmpty());
		//l1.clear();
		System.out.println(l1.lastIndexOf(23));
		
		System.out.println(" using for each...");
		for( Object o: l1)
			System.out.println(o);
		
		System.out.println(" using itertaor....");
		Iterator i=l1.iterator(); //faster, remove is possible 
		while(i.hasNext()) {
			if ((Integer)i.next()==23)
				i.remove();
			else
			System.out.println(i.next());
		}
		System.out.println(" using itertaor....");
		//legacy, slow,method names are bigger size ,remove is not possible 
		Enumeration e=l1.elements(); 
		while(e.hasMoreElements()) {
			System.out.println(e.nextElement());
		}
		/*Scanner sc=new Scanner(System.in);
		ArrayList list2=new ArrayList();
		list2.add(sc.nextInt());
		*/
		
		List<Double> list1=Arrays.asList(23.23,45.45,67.23,89.45,67.65,789.345);
		System.out.println(" using stream()......");
		
		list1.stream().forEach(x1->System.out.println(x1));  //java8
		
		System.out.println(" using method reference operator ......");
		
		list1.stream().forEach(System.out::println);
		
		Object objarray[]=list1.toArray();
		
		List<Integer> list2=new ArrayList();
		list2.add(23);
		list2.add(25);
		list2.add(34);
		list2.add(67);
	
		Iterator it2=list2.iterator();
		while(it2.hasNext()) {
			Integer xx=(Integer)it2.next();
			if(xx==34)
				it2.remove();
			else
				System.out.println(xx);
		}
		
	}
}
