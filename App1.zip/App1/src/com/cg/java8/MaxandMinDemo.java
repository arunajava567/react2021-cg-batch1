package com.cg.java8;

import java.util.Arrays;

public class MaxandMinDemo {

	public static void main(String[] args) {
		int[] numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

		int max = Arrays.stream(numbers).reduce(0, (a, b) -> a > b ? a : b);  // 10
		int max1 = Arrays.stream(numbers).reduce(0, Integer::max);            // 10

		int min = Arrays.stream(numbers).reduce(1, (a, b) -> a < b ? a : b);  // 0
		int min1 = Arrays.stream(numbers).reduce(1, Integer::min);  

		
		System.out.println(max+"  "+max1 +"  "+min +"  "+min1);
	}

}
