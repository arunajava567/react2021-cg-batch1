package com.cg.java8;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
public class FindFirstDemo {
	public static void main(String[] args) {
	List<String> list = Arrays.asList("node", "java", "python", "ruby");
    Optional<String> result = list.stream()
            .filter(x -> !x.equalsIgnoreCase("node"))
            .findFirst();
      if (result.isPresent()) {
            System.out.println(result.get()); // java
        } else {
            System.out.println("no value?");
        }
	}
}
