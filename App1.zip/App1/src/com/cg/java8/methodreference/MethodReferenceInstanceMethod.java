package com.cg.java8.methodreference;
interface Sayable1{  
	    void say();  
		}  
public class MethodReferenceInstanceMethod {
	    public void saySomething(){   //instance method
			        System.out.println("Hello, this is non-static method.");  
			    }  
			    public static void main(String[] args) {  
			    MethodReferenceInstanceMethod obj = new MethodReferenceInstanceMethod(); // Creating object  
			    // Referring non-static method using reference  
			    Sayable1 sayable = obj::saySomething;  
			    // Calling interface method  
			    System.out.println("instance method invocation using method reference :: ");
	            sayable.say();  
	            // Referring non-static method using anonymous object  
	            Sayable1 sayable2 = new MethodReferenceInstanceMethod()::saySomething; // You can use anonymous object also  
	            // Calling interface method  
	            sayable2.say();  
    }  
}  
