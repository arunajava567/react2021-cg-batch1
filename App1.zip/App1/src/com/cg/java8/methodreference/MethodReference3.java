package com.cg.java8.methodreference;
import java.util.function.BiFunction; 
class Arithmetic{  
	public static int add(int a, int b){  
	    return a+b;  
	}  
}  
public class MethodReference3 {  
	public static void main(String[] args) {  
      BiFunction<Integer, Integer, Integer> x = Arithmetic::add;  
	    int result = x.apply(50, 420);  
	    System.out.println(result);  
	}  
}  
