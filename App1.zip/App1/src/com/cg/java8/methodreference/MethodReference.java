package com.cg.java8.methodreference;

import java.util.TreeSet;

interface Sayable{  
	    void say();  
	}  
class X
{
	public static void disp() {
		System.out.println("in disp method");
	}
}

	public class MethodReference {  
	    public static void saySomething(){  
	        System.out.println("Hello, this is static method.");  
	    }  
	    public static void main(String[] args) {  
	    	
	    	//saySomething();
	    	
	    	
        // Referring static method        Classname :: staticmethod;
	        Sayable sayable = MethodReference::saySomething;  
	        // Calling interface method  
	        sayable.say();  
	        sayable=X::disp;
	        sayable.say();  
	        
	        
	      
	    }  
	}  
