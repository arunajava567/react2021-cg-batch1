package com.cg.java8;

import java.util.function.Consumer;
import java.util.function.Supplier;

@FunctionalInterface   // with one single method, to  to implement lamba expression
interface myInterface {
  int getsq(int a);
}
@FunctionalInterface   // with one single method, to  to implement lamba expression
interface Test {
  int max(int a,int b);
}
public class FunctionalDemo {  

	public static void main(String[] args) {
		myInterface mi= (int a) -> {  a+=10;
			                         return a*a;
		                            };
		
		myInterface mi1=(int a) -> a*a*a;
		System.out.println(mi.getsq(6));
		System.out.println(mi1.getsq(6));
		Test t1=(a,b)-> a>b? a : b;
		System.out.println(t1.max(47, 5));
		
		Consumer<String> c= (String s)-> System.out.println(s);
		c.accept("Capgemini   using Consumer ");
		
		// ::    method reference operator 
		
		Consumer<String> c1=  System.out::println;
		c1.accept("using method reerence ::   -> hello ");
		
		Supplier<String> c2=() -> "Capgemini";
		
		System.out.println("Using Supplier :"+ c2.get());
		
		
		}
}
