package com.cg.java8;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FilterNullValueDemo {

	public static void main(String[] args) {
		  Stream<String> language = Stream.of("java", "python", "node", null, "ruby", null, "php");

	        //List<String> result = language.collect(Collectors.toList());

	        List<String> result = language.filter(x -> x!=null).collect(Collectors.toList());

	        result.forEach(System.out::println);
	        Stream<String> language1 = Stream.of("java", "python", "node");

	        //Convert a Stream to List
	        List<String> result1 = language1.collect(Collectors.toList());

	        result1.forEach(System.out::println);

	        

	        Stream<Integer> number = Stream.of(1, 2, 3, 4, 5);

	        List<Integer> result2 = number.filter(x -> x != 3).collect(Collectors.toList());

	        result2.forEach(x -> System.out.println(x));

	}

}
