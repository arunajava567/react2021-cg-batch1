package com.cg.java8;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;



 class Staff {

    private String name;
    private int age;
    private BigDecimal salary;
    
	public Staff(String name, int age, BigDecimal salary) {
		super();
		this.name = name;
		this.age = age;
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public BigDecimal getSalary() {
		return salary;
	}
	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}
   
}
public class StreamList {

	public static void main(String[] args) {
		 List<Staff> staff = Arrays.asList(
	                new Staff("mkyong", 30, new BigDecimal(10000)),
	                new Staff("jack", 27, new BigDecimal(20000)),
	                new Staff("lawrence", 33, new BigDecimal(30000))
	        );

	        //Before Java 8
	        List<String> result = new ArrayList<>();
	        for (Staff x : staff) {
	            result.add(x.getName());
	        }
	        System.out.println(result); 

	        //Java 8
	        List<String> collect = staff.stream().map(x -> x.getName()).collect(Collectors.toList());
	        System.out.println(collect);
	        
	        
	        String[][] array = new String[][]{{"a", "b"}, {"c", "d"}, {"e", "f"}};

	        // Java 8
	        String[] result1 = Stream.of(array)  // Stream<String[]>
	                .flatMap(Stream::of)        // Stream<String>
	                .toArray(String[]::new);    // [a, b, c, d, e, f]

	        for (String s : result1) {
	            System.out.println(s);
	        }
	        
	        System.out.println("===flatmap=====");
	        List<String> collect1 = Stream.of(array)     // Stream<String[]>
	                .flatMap(Stream::of)                // Stream<String>
	                .filter(x -> !"a".equals(x))        // filter out the a
	                .collect(Collectors.toList());      // return a List

	        collect1.forEach(System.out::println);
	}

}
/*

for(int x[]:numbers)
    {
        for(int y:x)
        {
            System.out.println("Number is: "+y);
            sum+=y;
        }
    }

*/
