package com.cg.java8;

import java.util.stream.Stream;

public class streamIterateDemo {

	public static void main(String[] args) {
		Stream.iterate(0, n -> n + 1)
        .limit(10)
        .forEach(x -> System.out.println(x));
		
		
		 Stream.iterate(0, n -> n + 1)
         .filter(x -> x % 2 != 0) //odd
         .limit(10)
         .forEach(x -> System.out.println(x));
	}

}
