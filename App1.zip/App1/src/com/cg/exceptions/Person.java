package com.cg.exceptions;

public class Person {

	
	public Person(String name, float age) {
		super();
		this.name = name;
		this.age = age;
	}
	String name;
	float age;
	
}
