package com.cg.exceptions;

class SavingAccount extends Account {
	
	private double minimumBalance=10000;
	@Override
	void  withdraw(double amount) {
		minimumBalance-=amount;
		   
	   }
}


public class Account {

	   int accNum;
	   double balance;
	   Person accHolder;//composition , has a relation
	   
	   
	  public int getAccNum() {
		return accNum;
	}

	public void setAccNum(int accNum) {
		this.accNum = accNum;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}

	void  withdraw(double amount) {
		  balance-=amount;
		   
	   }
	   
	  void  deposit(double amount) {
		  balance+=amount;
		   
	   }
	  
		
	  
	  public static void main(String[] args) {
		Person person=new Person("smith",25);
		Account account=new Account();
		account.setAccNum(111);
		account.setBalance(2000);
		account.setAccHolder(person);
		account.deposit(2000);
		System.out.println(account.getBalance());
		
		
		Person person1=new Person("kathy",25);
		Account account1=new Account();
		account1.setAccNum(112);
		account1.setBalance(3000);
		account1.setAccHolder(person1);
		account1.withdraw(2000);
		System.out.println(account1.getBalance());
		
	}

	
}
