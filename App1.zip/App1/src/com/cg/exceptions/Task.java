package com.cg.exceptions;
import java.util.*;


public class Task {

		public static void main(String[] args)  throws MinimumDepoistException{
			Scanner ss=new Scanner(System.in);
        int marks=ss.nextInt();
        if(marks<20)
        	throw new MinimumDepoistException("Low Score , so minimum fine has to be paid");
		
		}

	}