package com.cg.exceptions;

import java.io.FileReader;
import java.io.IOException;

public class MultiCatch {
			
	public static void main(String args[]) throws IOException  {
		//FileReader f=null;   //java7
			try(FileReader f=new FileReader("e:\\abc.txt")) {  // 1  try with resource
				// f=new FileReader("e:\\abc.txt");
			  int a = args.length;
			  System.out.println("a = " + a);
			  int b = 42 / a;
			  int c[] = { 1 };
			  c[42] = 99;
			} 
			catch(ArithmeticException|ArrayIndexOutOfBoundsException e) {  //2
			  System.out.println("Problem in operation. Details:" + e);
			}
			//finally {                              //3 no need to release the resource
			//	f.close();
			//}
			System.out.println("After try/catch blocks.");
		}
	}