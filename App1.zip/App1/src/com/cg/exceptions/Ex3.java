package com.cg.exceptions;

import java.util.Scanner;
//user defined exception
//custom exception
class MinimumDepoistException  extends   RuntimeException  //Throwable //Exception 
{	MinimumDepoistException(String msg) {
		System.out.println(msg);
		//super(msg);
	}
}
public class Ex3 {
	public static void main(String[] args) throws MinimumDepoistException {
		Scanner sc=new Scanner(System.in);
		int amt=sc.nextInt();
		if(amt<1000) 
			// throwsing     throw
			throw new MinimumDepoistException("Minimum amount to be deposited is 1000/-");
		else
			System.out.println(" Thank you for using banking services...");
		
		
		
	}

}
