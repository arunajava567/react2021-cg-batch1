package exceptions;
import java.io.*;
// throws .. checked exception , compiletime 
class Super1{
	void disp() throws IOException,InterruptedException 
	{	
	}
}
class Sub extends Super1
{   @Override
	void disp() throws IOException
	{		
	}
}
class A
{
	 void show() throws IOException ,InterruptedException   //exception propagation
	 {
		 ExceptionDemo1 e=new ExceptionDemo1();
		 e.getEmi();
	 }
	
}

public class ExceptionDemo1 {
	
	static public void getEmi() throws IOException ,InterruptedException    // compile / checked 
	{
		 Thread.sleep(500);
		 FileWriter f=new FileWriter("d:\\abc.txt");
		
	}
	public static void main(String[] args) throws IOException ,InterruptedException
	{	Thread.sleep(5000);  // compile time exception , checked exception 
		
		//FileWriter f=new FileWriter("d:\abc.txt");
		
		getEmi();   // exception propagation
		

	}

}
