package polymorphism;
class Ride
{
	int getSq(int s)
	{
		return s*s;  //area
	}
}

class MRide extends Ride {
	
	void show()
	{
		
	}
	
	@Override                 ///super class overriden method 
	int getSq(int s)
	{
		return 4*s; //perimeter
	}
}

class Mride1 extends MRide
{
	int getSq(int s)
	{
		return s*s*s; //perimeter
	}
}
public class Mridedemo {

	public static void main(String[] args) {
		Ride r=new Ride(); //runtime poly, dynamic , overiding 
		//dynamic binding
		System.out.println(r.getSq(5));  //area
		//MRide mr=new MRide();
		r=new MRide();
		System.out.println(r.getSq(5));  //peri
		
		
		
		
		
		
	//	Mride1 mr1=new Mride1();
	//	r=new MRide1();
	///	System.out.println(r.getSq(5));  //peri
		

	}

}
