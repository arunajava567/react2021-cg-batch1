package test.set6;

 class GenerateReceipt {
	int verifyParty(Receipt r) {
		return 1;
	}

}

public class Receipt {
	TransactionParty transactionParty; 
	String productsQR;
	public Receipt(TransactionParty transactionParty, String productsQR) {
		super();
		this.transactionParty = transactionParty;
		this.productsQR = productsQR;
	}

}
