package test.set6;
class InvalidEmployeeException extends Exception{
	InvalidEmployeeException(String msg) {
		super(msg);
	}
}
public class EmployeeCheck {
	String validateEmployee(Employee employee) throws InvalidEmployeeException {
		try {
			if ( (employee.getEmployeeName().length()>=3)  && employee.getEmployeeId()>=100)
				employee.status="success";
			else 
				if(employee.getEmployeeName()==null || employee.getEmployeeName().length()<3)
				throw new InvalidEmployeeException("Employee name invalid");
		} 
		catch(InvalidEmployeeException e)
		{
			employee.status=e.getMessage();
			throw e;
		}
		catch (Exception e1) {
			// TODO Auto-generated catch block
			try {
				throw new Exception("unknown error occured");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return employee.status;
	}
	
	public static void main(String[] args) throws InvalidEmployeeException {
		EmployeeCheck  empcheck=new EmployeeCheck();
		System.out.println(empcheck.validateEmployee(new Employee(10,"Ra",null)));
	}
}



 class Employee{
	Integer employeeId;
	String employeeName;
	String status;
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Employee(Integer employeeId, String employeeName, String status) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.status = status;
	}
	
	

}
