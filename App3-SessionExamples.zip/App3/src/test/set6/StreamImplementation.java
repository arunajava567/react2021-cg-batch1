package test.set6;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
class Person{
	String name;
	int age;
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
	
}
public class StreamImplementation {

	
	public int summationOfAge(List<Person> list) {
		int sum=list.stream().
				reduce(0,(partialAge,p) -> {
					int age=p.getAge();
					if(age<=50) {
						age=0;
					}
					return partialAge+age;
				},Integer::sum);
		return sum;
					
				}
		
	public List<String> getPersonName(List<Person> list){
		List<String> result=list.stream()
				.map(person ->person.getName())
				.collect(Collectors.toList());
		return result;
	}
	public List<Integer> getPersonAge(List<Person> list){
		List<Integer> result=list.stream()
			.map(person ->person.getAge())
			.collect(Collectors.toList());
		return result;
	}
	public static void main(String[] args) {
       List<Person> list=new ArrayList<Person>();
       list.add(new Person("Ram",45));
       list.add(new Person("kiran",94));
       list.add(new Person("shiv",85));
       list.add(new Person("Hari",15));
       StreamImplementation si=new StreamImplementation();
       System.out.println(si.summationOfAge(list));
       System.out.println(si.getPersonAge(list));
       System.out.println(si.getPersonName(list));
       


	}

}
