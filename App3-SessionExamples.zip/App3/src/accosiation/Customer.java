package accosiation;

//has a   - composiion
public class Customer  {
	public static void main(String[] args) {
		 //Account account;   //refereing account in cutsomer -- has a relation
		// Person p=new Person();
		Account account =new Account();
		account.setAccNumber(101);
		account.setAccHolderName("ABC");
		System.out.println(account.getAccNumber()+"  "+account.getAccHolderName());
		
	}  

}
