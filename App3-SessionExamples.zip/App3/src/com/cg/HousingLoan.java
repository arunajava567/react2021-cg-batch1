package com.cg;
//multiple inheritance is not possible 
//diamond problem 
public class HousingLoan extends Loan {
	
	String address;
	
	HousingLoan() {
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HousingLoan hl= new HousingLoan();
		
	}

}
