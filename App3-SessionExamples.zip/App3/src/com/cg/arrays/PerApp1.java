package com.cg.arrays;

import com.cg.Person;
import com.cg.Product;

import static com.cg.Product.*;

public class PerApp1 extends Person{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Product p=new Product();
		System.out.println(mname);
		disp();
	}

}
