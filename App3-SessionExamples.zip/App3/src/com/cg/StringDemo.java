package com.cg;
// lava.lang
//import java.lang.String;

public class StringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 String name="Capgemini";   //string literal
		 String cname=new String("Capgemini"); //string object
		 //immutable
         //  memory		//not synchronized , fast 
		 System.out.println(name);
		 System.out.println(name.toUpperCase());//duplicate
		 System.out.println(name.startsWith("C"));
		 System.out.println(name.concat("TEchnologies"));
		 
		 //mutable ,never duplicates, syncronized, slow
		 StringBuilder sb=new StringBuilder(name);//fast, not syncronized 
		 //StringBuffer sb=new StringBuffer(name);
		 sb.append(7979.2323);
		 System.out.println(sb);
		 sb.insert(3, "XXXX");
		 System.out.println(sb.toString().toLowerCase());
			
		 sb.delete(5, 8);
		 System.out.println(sb);
		 System.out.println(sb.capacity());
		 //sb.ensusureCapacity(100);
		 System.out.println(sb.reverse());
		 String ss=sb.toString();
		 
		 
		 //System.out.println(s1.equals(s2));
		 // Scanner, Date ,Time,Calender,String,SB,SB,Object...System
		 //java.lang 
		 //System.exit(0);
		 //System.gc();
		 System.out.println("jsgdfjgsdhjgd");
		 System.out.println(System.currentTimeMillis());
			for(int i=0;i<=1000000;i++) {
				System.out.println("===");
			}
			System.out.println(System.currentTimeMillis());
		 
		 
		 
	}

}
