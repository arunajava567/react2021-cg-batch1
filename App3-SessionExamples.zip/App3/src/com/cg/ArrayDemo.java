package com.cg;
class Bank{
	int id;
	String name;
	public Bank(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Bank [id=" + id + ", name=" + name + "]";
	}
	
}
public class ArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {3,4,5,6,7}; //initialization
		int b[]=new int[10]; //declaration  homogeneous
		for(int i=0;i<a.length;i++)
			System.out.println(a[i]);
		System.out.println("for each - enhanced for ");
		for( int x : a)
			System.out.println(x);
		
		Bank b1=new Bank(1,"ICICI");
		
		Bank b2=new Bank(2,"HDFC");
		Bank b3=new Bank(3,"AXIS");
		
	//	Object bankArray[]=new Object[2]; //object
		
		
		Bank banks[]=new Bank[3];  //bank type of array
		banks[0]=b1;
		banks[1]=b2;  //......
		banks[2]=b3;
		
		int sumofId=0;

		//
		for(int i=0;i<banks.length;i++) {
			System.out.println(banks[i]);
			sumofId+=banks[i].getId();
		}
		
		System.out.println(sumofId);
		for(Bank  x : banks)
			System.out.println(x.getName().toLowerCase());
		
		String city[]=new String[5];
		city[0]="Hyd";
		city[1]="Chennai";
		                   //array
		for(int i=0;i<city.length;i++)
			System.out.println(city[i]);
		
		String cname="Capgemini";
		System.out.println(cname.length()); //string
		
		for(String x : city)
			System.out.println(x);
		
		
	}

}
