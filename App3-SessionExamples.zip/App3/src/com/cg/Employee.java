package com.cg;

public class Employee {

	@Override
	public String toString() {
		return "Employee []";
	}

}
