package com.cg;

//Var Args Demo

public class VarArgsDemo
{
	static {
	System.out.println("before main ");
	}
	
static 	int add(int a,int b) //fixed 
	{
		return a+b;
	}
	static int sum(int... n)  //variable 
	{
		int sum=0;
	
		for(int i=0;i<n.length;i++)
			sum = sum + n[i];

		return sum;	
	}
	public static void main(String[] args)
	{
		System.out.println(add(8,9));
		
		System.out.println(sum(10,20,30,67,45));

		System.out.println(sum(10,20,30,40,50));
		
		System.out.println(sum(10,20));
	}
}