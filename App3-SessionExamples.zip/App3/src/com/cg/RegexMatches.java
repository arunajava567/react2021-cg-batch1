package com.cg;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexMatches {

   public static void main( String args[] ) {
      // String to be scanned to find the pattern.
      String line = "This order was placed for QT3000! OK?";
      String pattern = "(.*)(\\d+)(.*)";

      // Create a Pattern object
      Pattern r = Pattern.compile(pattern);

      // Now create matcher object.
      Matcher m = r.matcher(line);
      if (m.find( )) {
         System.out.println("Found value: " + m.group(0) );
         System.out.println("Found value: " + m.group(1) );
         System.out.println("Found value: " + m.group(2) );
      }else {
         System.out.println("NO MATCH");
      }
      
      String pattern1="[a-zA-Z][xy]";
      String line="hy";
      //set pattern
      Pattern p=Pattern.compile(pattern1);
      
      Matcher m=p.matcher(line);
   //  line.matches(regex)
      if (m.find())
      {
    	  System.out.println("match is success");
      }
      else {
    	  System.out.println("not success");
      }
    	 
   }
}