package com.cg.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.TreeSet;

class NameComparator implements Comparator {
	public int compare(Object o1,Object o2) {
		Product p1=(Product)o1;
		Product p2=(Product)o2;   //s1.compareTo(s2)  >1   s1>s2  , <1  s1<s2 , =0 s1=s2 
		if (  (p1.name).compareTo(p2.name) >1)
			return +1;
		else  if (  (p1.name).compareTo(p2.name) <1)
			return -1;
		else
			return 0;
		
		
	}
}

class PriceComparator implements Comparator {
	public int compare(Object o1,Object o2) {
		Product p1=(Product)o1;
		Product p2=(Product)o2;   //s1.compareTo(s2)  >1   s1>s2  , <1  s1<s2 , =0 s1=s2 
		if (  p1.price>p2.price)
			return +1;
		else  if (  p1.price<p2.price)
			return -1;
		else
			return 0;
		
		
	}
}



class Product //implements Comparable
{
	
	int id;
	String name;
	double price;
	double qty;
	
	/*public int compareTo(Object o) {
		Product p=(Product)o;
		if (this.id>p.id)
			return +1;
		else  if(this.id<p.id)
			return -1;
		else
			return 0;
		
		
	}
	*/
	
	public Product(int id, String name, double price, double qty) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.qty = qty;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getQty() {
		return qty;
	}
	public void setQty(double qty) {
		this.qty = qty;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + ", qty=" + qty + "]";
	}
	
}


public class ComparableDemo {

	public static void main(String[] args) {
		
	//	ArrayList<Product> plist=new ArrayList<Product>();
	//	HashSet<Product> plist=new HashSet<Product>();
		TreeSet<Product> plist=new TreeSet<Product>(new NameComparator());  //default sorted
		plist.add(new Product(3,"Bag",900,50));
		plist.add(new Product(4,"Book",400,80));
		plist.add(new Product(2,"Table",300,90));
		plist.add(new Product(1,"Pen",200,54));
		plist.add(new Product(6,"Box",800,20));
		
		TreeSet ts=new TreeSet();// integer, string 
		ts.add(34);
		ts.add(12);
		ts.add(78);
		System.out.println(ts);
		
		System.out.println(plist);
	//	Collections.sort(plist,new NameComparator());
	//	Collections.sort(plist,new PriceComparator());
	//	System.out.println(plist);
       Iterator i=plist.iterator();
		
		while(i.hasNext())
		{		
				System.out.println(i.next());
			
		}
		
	}

}
 