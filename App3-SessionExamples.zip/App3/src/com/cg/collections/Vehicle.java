package com.cg.collections;

public class Vehicle {
   int id;
   String name;
   
}
