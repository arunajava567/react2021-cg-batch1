package com.cg.collections.generics;

public class GenericMethodTest
{
	// generic method printArray                         
	public  < E > void printArray( E[] inputArray )
	{
		// Display array elements              
		for ( E x : inputArray )
		{
			System.out.printf( "%s ", x );
		}
		System.out.println();
	}

	public static void main( String args[] )
	{GenericMethodTest g=new GenericMethodTest();
		
		// Create arrays of Integer, Double and Character
		Integer[] intArray = { 1, 2, 3, 4, 5 };

		Double[] doubleArray = { 1.1, 2.2, 3.3, 4.4 };
		
		Character[] charArray = { 'H', 'E', 'L', 'L', 'O' };
		
		String[] namesList= {"Amith","Raj","Amith"};
		g.printArray(namesList);

		System.out.println( "Array integerArray contains:" );
		g.printArray( intArray );									// pass an Integer array

		System.out.println( "\nArray doubleArray contains:" );
		g.printArray( doubleArray );								// pass a Double array

		System.out.println( "\nArray characterArray contains:" );
	} 
}