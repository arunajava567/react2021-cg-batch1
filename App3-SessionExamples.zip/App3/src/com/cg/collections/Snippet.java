package com.cg.collections;

public class Snippet {
	public static void main(String[] args) {
			hm.put(3, new Date());
	}
}

