package com.cg.collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;


public class CollectionApp {
	public static void main(String[] args) {
		Set l=new TreeSet<Integer>(); //ordered and unique
		//l.add("Capgemini");
		//TreeSet sorted 
		l.add(new Integer(2));
		l.add(32);
		l.add(33);
		l.add(42);
		l.add(3);
		l.add(34);
		
		
	//	l.add(new Date());
	//	l.add("Capgemini");
		//l.add(new Vehicle());
	//	l.add("Capgemini");
		System.out.println(l);
		System.out.println(l.size());
	//	System.out.println(l.get(2));
	//	System.out.println(l.contains("Capgemini"));
	 //System.out.println(l.indexOf("Capgemini"));
	//	System.out.println(l.lastIndexOf("Capgemini"));
		//l.clear();
		System.out.println(l.isEmpty());
		System.out.println(l.remove(3));
		List l1=new ArrayList();
		l1.add(56);
		l1.add(78);
		l1.add(90);
		//bulk  addAll()   removeAll()  retainAll() containsAll()
		l.addAll(l1);
		System.out.println(l);
		//l.removeAll(l1);
		//System.out.println(l);
		//l.retainAll(l1);  //intersection
		//System.out.println(l);
		System.out.println(l.containsAll(l1));
		System.out.println(l);
		
		
		
		System.out.println("using for each");
		for( Object o : l)
		{System.out.println(o);
		}
		
		
		System.out.println("using iterator");
		Iterator i=l.iterator();  // remove
		while(i.hasNext()) {
			//System.out.println(i.next());  //object 
			/*Integer i1=(Integer)i.next();
			if(i1==3)
				i.remove();
			else*/
				System.out.println(i.next());
		}
		System.out.println("Vector leements");

		/*Enumeration e=l.elements();
		while(e.hasMoreElements()) {
			System.out.println(e.nextElement());
		}
		*/
		
		Object o[]=l.toArray();   // any collection class can be converted into array , object 
		
		
	}

}
