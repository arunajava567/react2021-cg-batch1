package com.exceptions.client;
//custom exception,  userdefined exception

import com.exceptions.exception.DepositException;
import com.exceptions.service.Account;

//client
public class Client {

	public static void main(String[] args) throws DepositException {

		Account a=new Account();
		a.deposit(2000);
		System.out.println(a.getBalance());
		a.deposit(12000);
		System.out.println(a.getBalance());
		
	}

}
