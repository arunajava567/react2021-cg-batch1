package com.cg.java8.methodreference;
		interface Messageable{  
		    Message getMessage(String msg);  
		}  
		class Message{  
		    Message(String msg){  
		        System.out.print(msg);  
		    }  
		}  
		public class MethodReferenceConstructor3 {
		    public static void main(String[] args) {  
		        Messageable x = Message::new;  // classname :: new    constructor 
		        x.getMessage("Hello");  
		    }  
		}  
