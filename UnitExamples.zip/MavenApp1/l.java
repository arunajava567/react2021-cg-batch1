package com.cg.MavenApp1;

public class l {

	public static int getEmi(int i) {
		// TODO Auto-generated method stub
		return i/5;
	}

	public static int getInterest(int i) {
		// TODO Auto-generated method stub
		return i/25;
	}

}
