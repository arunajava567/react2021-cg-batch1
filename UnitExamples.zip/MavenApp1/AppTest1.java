package com.cg.MavenApp1;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.
assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.gen5.api.AfterAll;
import org.junit.gen5.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;


public class AppTest1 {
  App a;
  int x;
	@BeforeAll
	public void setUp() throws Exception {
		 a=new App();
	}

	@AfterAll
	public void tearDown() throws Exception {
		a=null;
	}

	@Test
	public void testSayHello() {
		//fail("Not yet implemented");
        
		
		assertNotEquals("Hello123",a.sayHello());
		
	}
	@BeforeEach
	public void setup() {
		 x=10;
	}
	@Disabled
	@Test
	public void testSquare() {
		//fail("Not yet implemented");
        
		
		assertEquals(x,a.square(4));
		
	}

}
