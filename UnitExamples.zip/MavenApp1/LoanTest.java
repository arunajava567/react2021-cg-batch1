package com.cg.MavenApp1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class LoanTest {
//Loan l;
	@BeforeEach
	void setUp() throws Exception {
	//	l=new Loan();
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void test() {
		
		assertEquals(2000,l.getEmi(10000));
		//fail("Not yet implemented");
	}
	@Test
	void test1() {
		
		assertEquals(800,l.getInterest(90000));
		//fail("Not yet implemented");
	}
	

}
