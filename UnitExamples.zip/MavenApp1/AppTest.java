package com.cg.MavenApp1;

import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;
class SumTest {

	@Test
	void testGetSum() {
		App a=new App();
		
		assertEquals("Hello",a.sayHello());
		
		
		
		
		
	//	fail("Not yet implemented");
	}

}
