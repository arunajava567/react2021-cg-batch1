package com.cg.MavenApp1;

//import static org.junit.Assert;
import static org.junit.Assert.assertEquals;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

public class ParameterizedTestDemo {
	@ParameterizedTest
	@ValueSource(strings = { "Hello", "JUnit","java2","sprig" ,"23423"})
	void withValueSource(String word) {
		int l=word.length();
		assertEquals(l,5);
	}
	}