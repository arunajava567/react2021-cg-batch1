package com.cg.MavenApp1;


public class HelloWorld 
{
   public String say() 
   { 
      return("HelloWorld!"); 
    }
 } 

