package com.cg2021.MyFirstMavenProject;

import static org.junit.Assert.*;

import org.junit.Test;

public class LoanTest {

	@Test
	public void testGetEmi() {
		
		Loan l=new Loan();
		int emi =l.getEmi(6000);
		
		assertEquals(emi,800);
		//fail("Not yet implemented");
	}

}
