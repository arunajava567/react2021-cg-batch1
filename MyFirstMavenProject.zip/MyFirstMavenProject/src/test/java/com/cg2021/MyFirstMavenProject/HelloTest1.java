package com.cg2021.MyFirstMavenProject;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class HelloTest1 {
Hello h;
	@Before
	public void setUp() throws Exception {
		h=new Hello();
	}

	@After
	public void tearDown() throws Exception {
		h=null;
	}

	@Test
	public void testSayHello() {
		assertEquals("hello",h.sayHello());
		//fail("Not yet implemented");
	}

}
