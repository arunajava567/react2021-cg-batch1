package com.cg2021.MyFirstMavenProject;

import static org.junit.Assert.*;

import org.junit.Test;

public class HelloTest {

	@Test
	public void testSayHello() {
		Hello h=new Hello();
		assertEquals("hello123",h.sayHello());
		
		
		//fail("Not yet implemented");
	}

}
