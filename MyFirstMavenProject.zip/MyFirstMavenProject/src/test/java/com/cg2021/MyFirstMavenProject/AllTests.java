package com.cg2021.MyFirstMavenProject;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ AppTest.class, HelloTest.class, HelloTest1.class, HelloTest2.class, LoanTest.class })
public class AllTests {

}
