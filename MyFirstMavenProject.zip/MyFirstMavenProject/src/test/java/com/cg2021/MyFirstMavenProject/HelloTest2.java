package com.cg2021.MyFirstMavenProject;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class HelloTest2 {
	Hello h;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		h=new Hello();
	}

	@After
	public void tearDown() throws Exception {
		h=null;
	}

	@Test
	public void testSayHello() {
		assertEquals("hello",h.sayHello());
		//fail("Not yet implemented");
	}

	@Test
	
	public void testSum() {
		assertEquals(10,h.sum(6, 4));
		//fail("Not yet implemented");
	}

	@Test
	public void testProd() {
		fail("Not yet implemented");
	}

}
