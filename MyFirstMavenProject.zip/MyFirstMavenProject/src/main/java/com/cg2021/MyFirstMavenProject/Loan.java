package com.cg2021.MyFirstMavenProject;

public class Loan {
	
	public int getEmi(int amount) {
		return amount/12;
	}
	

}
