package com.cg2021.MyFirstMavenProject;

public class Hello {

	
	public String sayHello( ) {
		return "hello";
	}
	
	public int sum(int a,int b) {
		return a+b;
	}
	public int prod(int a,int b) {
		return a*b;
	}
	
}
